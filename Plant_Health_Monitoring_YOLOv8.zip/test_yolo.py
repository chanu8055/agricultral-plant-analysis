from ultralytics import YOLO

# Load the best trained model
model = YOLO("runs/detect/plant_health_detect/weights/best.pt")

# Run prediction on test images
results = model.predict(source="test_images", save=True)

print("✅ Prediction complete! Check results inside 'runs/predict/'.")
