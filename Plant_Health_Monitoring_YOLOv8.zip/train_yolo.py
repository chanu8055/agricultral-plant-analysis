from ultralytics import YOLO

# Load a pre-trained YOLOv8 model (nano version for faster training)
model = YOLO("yolov8n.pt")

# Train the model
model.train(
    data="data.yaml",
    epochs=30,
    imgsz=640,
    name="plant_health_detect",
)

print("✅ Training complete! Model saved inside 'runs/detect/plant_health_detect'.")
